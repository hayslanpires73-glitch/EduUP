<?php
/**
 * Ponto de entrada do Servidor PHP
 * Permite rodar com: php -S localhost:8000
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Se a requisição for para a API
if (str_starts_with($uri, '/api')) {
    require __DIR__ . '/backend/index.php';
    exit;
}

// Se for um arquivo estático existente (CSS, JS, Imagens, SVG)
$filePath = __DIR__ . $uri;
if ($uri !== '/' && file_exists($filePath) && !is_dir($filePath)) {
    return false; // Permite que o servidor embutido do PHP sirva o arquivo estático
}

// Caso contrário, serve o index.html principal
readfile(__DIR__ . '/index.html');
exit;
